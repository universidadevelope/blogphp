<?php
include '../model/Perfil.class.php';
include '../dao/PerfilDAO.class.php';

$perfil = new Perfil(9, 'Administrador');

$perfilDao = new PerfilDAO();

//$perfilDao->insert($perfil);
//$perfilDao->update($perfil);
//$perfilDao->delete(9);


$rs = $perfilDao->getPerfil();
try {
	foreach ($rs as $row) {
		echo $row["StrPerfil"] . "<br>";
	}
} catch (Exception $e) {
	echo 'Erro: '.$e;
}