$("#btnLogin").click(()=>{
	location.href="../principal/index.php";
});