<?php include '../../includes/head.php'; ?>
<div class="container">
	<div class="jumbotron">
		<h1 class="display-4">Bem vindo ao Blog!</h1>
		<p class="lead">Esta é a página de administração do seu blog.</p>
		<hr class="my-4">
		<p>No menu acima você pode gerenciar o seu blog.</p>
	</div>
</div>
<?php include '../../includes/footer.php'; ?>	