<?php
	header('Location: view/login/index.php');
?>