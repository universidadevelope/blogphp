<?php
Class Perfil{
	private $NumIdPerfil;
	private $StrPerfil;

	function __Construct($NumIdPerfil, $StrPerfil){
		$this->NumIdPerfil = $NumIdPerfil;
		$this->StrPerfil = $StrPerfil;
	}

	function getNumIdPerfil(){
		return $this->NumIdPerfil;
	}

	function getStrPerfil(){
		return $this->StrPerfil;
	}
}