<?php
Class Usuario{

	private $NumIdUsuario;
	private $NumIdPerfil;
	private $StrNome;
	private $StrUsuario;
	private $StrSenha;
	private $StrEmail;

	function __Construct($NumIdUsuario,$NumIdPerfil,$StrNome,$StrUsuario,$StrSenha,$StrEmail){
		$this->NumIdUsuario=$NumIdUsuario;
		$this->NumIdPerfil=$NumIdPerfil;
		$this->StrNome=$StrNome;
		$this->StrUsuario=$StrUsuario;
		$this->StrSenha=$StrSenha;
		$this->StrEmail =$StrEmail;
	}

	function getNumIdUsuario(){
		return $this->NumIdUsuario;
	}

	function getNumIdPerfil(){
		return $this->NumIdPerfil;
	}

	function getStrNome(){
		return $this->StrNome;
	}

	function getStrUsuario(){
		return $this->StrUsuario;
	}

	function getStrSenha(){
		return $this->StrSenha;
	}

	function getStrEmail(){
		return $this->StrEmail;
	}
}
