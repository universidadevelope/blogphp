<?php
Class Comentario{
	private $NumIdComentario;
	private $NumIdPostagem;
	private $StrComentario;
	private $DtComentario;

	function __Construct($NumIdComentario,$NumIdPostagem,$StrComentario,$DtComentario){
		$this->NumIdComentario = $NumIdComentario;
		$this->NumIdPostagem = $NumIdPostagem;
		$this->StrComentario = $StrComentario;
		$this->DtComentario = $DtComentario;
	}

	function getNumIdComentario(){
		return $this->NumIdComentario;
	}

	function getNumIdPostagem(){
		return $this->NumIdPostagem;
	}

	function getStrComentario(){
		return $this->StrComentario;
	}

	function getDtComentario(){
		return $this->DtComentario;
	}
}