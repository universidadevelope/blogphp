<?php
Class Postagem{
	private $NumIdPostagem;
	private $NumIdCategoria;
	private $StrTitulo;
	private $StrResumo;
	private $StrConteudo;
	private $DtPostagem;
	private $DtFim;

	function __Construct($NumIdPostagem,$NumIdCategoria,$StrTitulo,$StrResumo,$StrConteudo,$DtPostagem,$DtFim){
		$this->NumIdPostagem = $NumIdPostagem;
		$this->NumIdCategoria = $NumIdCategoria;
		$this->StrTitulo = $StrTitulo;
		$this->StrResumo = $StrResumo;
		$this->StrConteudo = $StrConteudo;
		$this->DtPostagem = $DtPostagem;
		$this->DtFim = $DtFim;
	}

	function getNumIdPostagem(){
		return $this->NumIdPostagem;
	}

	function getNumIdCategoria(){
		return $this->NumIdCategoria;
	}

	function getStrTitulo(){
		return $this->StrTitulo;
	}

	function getStrResumo(){
		return $this->StrResumo;
	}

	function getStrConteudo(){
		return $this->StrConteudo;
	}

	function getDtPostagem(){
		return $this->DtPostagem;
	}
	
	function getDtFim(){
		return $this->DtFim;
	}
}