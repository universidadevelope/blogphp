<?php
Class Categoria{
	private $NumIdCategoria;
	private $StrCategoria;

	function __Construct($NumIdCategoria,$StrCategoria){
		$this->NumIdCategoria = $NumIdCategoria;
		$this->StrCategoria = $StrCategoria;
	}

	function getNumIdCategoria(){
		return $this->NumIdCategoria;
	}

	function getStrCategoria(){
		return $this->StrCategoria;
	}
}