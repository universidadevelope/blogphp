<?php
include '../includes/Connection.class.php';

Class ComentarioDAO{
	private $cn;

	function __Construct(){
		$pdo = new Connection();
		$this->cn = $pdo->getConnect();
	}

	function insert(Comentario $comentario){
		try {
			$sql = 'insert into comentario(NumIdPostagem, StrComentario, DtComentario) values(?,?,?)';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $comentario->getNumIdPostagem());
			$stmt->bindParam(2, $comentario->getStrComentario());
			$stmt->bindParam(3, $comentario->getDtComentario());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function update(Comentario $comentario){
		try {
			$sql = 'update comentario set NumIdPostagem = ?, StrComentario=?, DtComentario=? where NumIdComentario = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $comentario->getNumIdPostagem());
			$stmt->bindParam(2, $comentario->getStrComentario());
			$stmt->bindParam(3, $comentario->getDtComentario());
			$stmt->bindParam(4, $comentario->getNumIdComentario());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function delete($NumIdComentario){
		try {
			$sql = 'delete from comentario where NumIdComentario = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $NumIdComentario);
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function getComentario(){
		$sql = 'select NumIdComentario, NumIdPostagem, StrComentario, DtComentario from comentario';
		$stmt = $this->cn->prepare($sql);
		$stmt->execute();
		$rs = $stmt->fetchall(PDO::FETCH_ASSOC);
		return $rs;
	}

}