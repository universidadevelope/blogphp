<?php
include '../includes/Connection.class.php';

Class PerfilDAO{
	private $cn;

	function __Construct(){
		$pdo = new Connection();
		$this->cn = $pdo->getConnect();
	}

	function insert(Perfil $perfil){
		try {
			$sql = 'insert into perfil(StrPerfil) values(?)';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $perfil->getStrPerfil());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function update(Perfil $perfil){
		try {
			$sql = 'update perfil set StrPerfil = ? where NumIdPerfil = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $perfil->getStrPerfil());
			$stmt->bindParam(2, $perfil->getNumIdPerfil());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function delete($NumIdPerfil){
		try {
			$sql = 'delete from perfil where NumIdPerfil = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $NumIdPerfil);
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function getPerfil(){
		$sql = 'select NumIdPerfil, StrPerfil from perfil';
		$stmt = $this->cn->prepare($sql);
		$stmt->execute();
		$rs = $stmt->fetchall(PDO::FETCH_ASSOC);
		return $rs;
	}

}