<?php
include '../includes/Connection.class.php';

Class UsuarioDAO{
	private $cn;

	function __Construct(){
		$pdo = new Connection();
		$this->cn = $pdo->getConnect();
	}

	function insert(Usuario $usuario){
		try {
			$sql = 'insert into usuario(NumIdPerfil,StrNome,StrUsuario,StrSenha,StrEmail) values(?,?,?,?,?)';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $usuario->getNumIdPerfil());
			$stmt->bindParam(2, $usuario->getStrNome());
			$stmt->bindParam(3, $usuario->getStrUsuario());
			$stmt->bindParam(4, $usuario->getStrSenha());
			$stmt->bindParam(5, $usuario->getStrEmail());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function update(Usuario $usuario){
		try {
			$sql = 'update usuario set NumIdPerfil=?,StrNome=?,StrUsuario=?,StrSenha=?,StrEmail=? where NumIdUsuario = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $usuario->getNumIdPerfil());
			$stmt->bindParam(2, $usuario->getStrNome());
			$stmt->bindParam(3, $usuario->getStrUsuario());
			$stmt->bindParam(4, $usuario->getStrSenha());
			$stmt->bindParam(5, $usuario->getStrEmail());
			$stmt->bindParam(6, $usuario->getNumIdUsuario());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function delete($NumIdUsuario){
		try {
			$sql = 'delete from usuario where NumIdUsuario = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $NumIdUsuario);
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function getUsuario(){
		$sql = 'select NumIdUsuario,NumIdPerfil,StrNome,StrUsuario,StrSenha,StrEmail from usuario';
		$stmt = $this->cn->prepare($sql);
		$stmt->execute();
		$rs = $stmt->fetchall(PDO::FETCH_ASSOC);
		return $rs;
	}

}