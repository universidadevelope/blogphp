<?php
include '../includes/Connection.class.php';

Class CategoriaDAO{
	private $cn;

	function __Construct(){
		$pdo = new Connection();
		$this->cn = $pdo->getConnect();
	}

	function insert(Categoria $categoria){
		try {
			$sql = 'insert into categoria(StrCategoria) values(?)';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $categoria->getStrCategoria());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function update(Categoria $categoria){
		try {
			$sql = 'update categoria set StrCategoria = ? where NumIdCategoria = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $categoria->getStrCategoria());
			$stmt->bindParam(2, $categoria->getNumIdCategoria());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function delete($NumIdCategoria){
		try {
			$sql = 'delete from categoria where NumIdCategoria = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $NumIdCategoria);
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function getCategoria(){
		$sql = 'select NumIdCategoria, StrCategoria from categoria';
		$stmt = $this->cn->prepare($sql);
		$stmt->execute();
		$rs = $stmt->fetchall(PDO::FETCH_ASSOC);
		return $rs;
	}

}