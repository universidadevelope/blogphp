<?php
include '../includes/Connection.class.php';

Class PostagemDAO{
	private $cn;

	function __Construct(){
		$pdo = new Connection();
		$this->cn = $pdo->getConnect();
	}

	function insert(Postagem $postagem){
		try {
			$sql = 'insert into postagem(NumIdCategoria,StrTitulo,StrResumo,StrConteudo,DtPostagem,DtFim) values(?,?,?,?,?,?)';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $postagem->getNumIdCategoria());
			$stmt->bindParam(2, $postagem->getStrTitulo());
			$stmt->bindParam(3, $postagem->getStrResumo());
			$stmt->bindParam(4, $postagem->getStrConteudo());
			$stmt->bindParam(5, $postagem->getDtPostagem());
			$stmt->bindParam(6, $postagem->getDtFim());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function update(Postagem $postagem){
		try {
			$sql = 'update postagem set NumIdCategoria=?,StrTitulo=?,StrResumo=?,StrConteudo=?,DtPostagem=?,DtFim=? where NumIdPostagem = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $postagem->getNumIdCategoria());
			$stmt->bindParam(2, $postagem->getStrTitulo());
			$stmt->bindParam(3, $postagem->getStrResumo());
			$stmt->bindParam(4, $postagem->getStrConteudo());
			$stmt->bindParam(5, $postagem->getDtPostagem());
			$stmt->bindParam(6, $postagem->getDtFim());
			$stmt->bindParam(7, $postagem->getNumIdPostagem());
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function delete($NumIdPostagem){
		try {
			$sql = 'delete from postagem where NumIdPostagem = ?';
			$stmt = $this->cn->prepare($sql);
			$stmt->bindParam(1, $NumIdPostagem);
			return $stmt->execute();
		} catch (PDOException $e) {
			echo 'ERRO: ' . $e;
		}
	}

	function getPostagem(){
		$sql = 'select NumIdPostagem, Categoria,StrTitulo,StrResumo,StrConteudo,DtPostagem,DtFim from postagem';
		$stmt = $this->cn->prepare($sql);
		$stmt->execute();
		$rs = $stmt->fetchall(PDO::FETCH_ASSOC);
		return $rs;
	}

}