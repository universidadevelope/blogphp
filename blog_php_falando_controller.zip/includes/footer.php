		<script src="../../plugins/jquery-3.3.1.min.js"></script>
		<script src="../../plugins/popper.min.js"></script>
		<script src="../../plugins/bootstrap-4.3.1-dist/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/mScript.js"></script>
		<script type="text/javascript" src="js/mFunction.js"></script>
	</body>
</html>