<?php
Class Connection{
	private $cn;

	function getConnect(){
		try {
			$this->cn = new PDO('mysql:host=localhost;dbname=blogphp', 'root', '');
			$this->cn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		} catch (PDOException $e) {
			echo 'Erro ao se conectar ao banco de dados: ' . $e;
		}
		return $this->cn;
	}
}